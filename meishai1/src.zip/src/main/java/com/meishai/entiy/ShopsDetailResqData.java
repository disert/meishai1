package com.meishai.entiy;

/**
 * Created by Administrator on 2015/12/4.
 *
 * 新增 好店详情的数据由该类来表示,添加一个urldata数据
 *
 */
public class ShopsDetailResqData extends SpecialDetailResqData {

    public UrlData urldata;

}
