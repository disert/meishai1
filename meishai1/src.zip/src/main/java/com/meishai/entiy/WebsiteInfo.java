package com.meishai.entiy;

/**
 * 文件名：WebsiteInfo
 * 描    述：用于描述网站信息的实体类
 * 作    者：yl
 * 时    间：2016/1/13
 * 版    权：
 */
public class WebsiteInfo {
    public String icon;
    public String name;
    public String url;

}
