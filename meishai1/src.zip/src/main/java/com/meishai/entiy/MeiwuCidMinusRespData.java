package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：MeiwuCidMinusRespData
 * 描    述：美物cid为-1时的数据
 * 作    者：yl
 * 时    间：2016/1/20
 * 版    权：
 */
public class MeiwuCidMinusRespData extends BaseRespData {

    public List<CateInfo> list;
}
