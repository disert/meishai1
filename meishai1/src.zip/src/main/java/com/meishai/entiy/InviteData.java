package com.meishai.entiy;

/**
 * Created by Administrator on 2016/4/23.
 */
public class InviteData extends BaseRespData {
    public ShareData data;
}
