package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：
 * 描    述：美晒 发现 item tempid=2 更多的数据
 * 作    者：
 * 时    间：2016/2/18
 * 版    权：
 */
public class MoreTempid2Data extends BaseResp<CateResponseData.CateInfo1> {



}
