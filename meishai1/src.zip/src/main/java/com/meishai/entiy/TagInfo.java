package com.meishai.entiy;

/**
 * 文件名：TagInfo
 * 描    述：发布页面中标签的数据
 * 作    者：
 * 时    间：2016/1/9
 * 版    权：
 */
public class TagInfo  {
    public String name;//	最萌美物
    public int tid;//	570
}
