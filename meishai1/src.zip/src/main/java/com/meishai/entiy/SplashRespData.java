package com.meishai.entiy;

/**
 * Created by Administrator on 2015/12/3.
 */
public class SplashRespData extends BaseRespData {

    public SplashData data;


}
