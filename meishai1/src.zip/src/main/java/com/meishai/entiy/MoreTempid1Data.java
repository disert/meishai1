package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：
 * 描    述：美晒 发现 item tempid=1 更多的数据
 * 作    者：
 * 时    间：2016/2/18
 * 版    权：
 */
public class MoreTempid1Data extends BaseResp<MoreTempid1Data.Tempid1ItemData> {

    public class Tempid1ItemData {

        public String image;// http
        public int isattention;// 0
        public List<HomePageDatas.PostInfo> pics;// Array
        public String text;// 42晒晒，共收获787565个赞
        public int tid;// 951
        public String title;// 无限回购
    }
}
