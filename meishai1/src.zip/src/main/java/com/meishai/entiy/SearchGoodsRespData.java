package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：SearchGoodsRespData
 * 描    述：发布界面点击添加链接时进入的界面的数据
 * 作    者：yl
 * 时    间：2016/1/13
 * 版    权：
 */
public class SearchGoodsRespData extends BaseRespData{
    public List<WebsiteInfo> list;
}
