package com.meishai.entiy;

import java.util.List;

import com.meishai.entiy.FreeTrialRespData.FreeTrailData;

/**
 * 限时抢购响应数据的封装类
 * 
 * @author Administrator yl
 *
 */
public class FlashSaleRespData extends BaseRespData {
	
	public List<FreeTrailData> list;


}
