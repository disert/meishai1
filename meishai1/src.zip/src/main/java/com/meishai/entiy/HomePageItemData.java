package com.meishai.entiy;

/**
 * 文件名：
 * 描    述：新的个人主页的每个item的数据
 * 作    者：
 * 时    间：2016/1/26
 * 版    权：
 */
public class HomePageItemData {
    public String image;//	http://img.meishai.com/2016/0114/20160114095604340.jpg_300x300.jpg
    public int pid;//	118023
}
