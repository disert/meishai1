package com.meishai.entiy;

import com.meishai.entiy.StrategyResqData.StratData;

/**
 * 美物-专场详情 的数据存储类
 *
 * @author Administrator
 */
public class SpecialDetailResqData extends SKUResqData {

    public ShareData sharedata;
    public StratDetailRespData.HeadData topicdata;
    public String page_title;//	专场详情页


}
