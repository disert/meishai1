package com.meishai.entiy;

/**
 * 文件名：ButtonData
 * 描    述：底部按钮信息的实体 来自于提交订单
 * 作    者：
 * 时    间：2015/12/18
 * 版    权：
 */
public class ButtonData {
    public int app_button;//	1
    public String app_button_text;//	提交订单
    public String text;//	您有：13525积分
    public String text_color;//	FF5577

}
