package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：
 * 描    述：
 * 作    者：
 * 时    间：2016/2/18
 * 版    权：
 */
public class MoreStarItemData extends BaseResp<StarItemData> {

}
