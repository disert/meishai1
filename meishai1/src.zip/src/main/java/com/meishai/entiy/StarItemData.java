package com.meishai.entiy;

import java.util.List;

/**
 * 文件名：
 * 描    述：达人之星 更多 item的数据
 * 作    者：
 * 时    间：2016/2/18
 * 版    权：
 */
public class StarItemData {

    public String avatar;//	http://img.meishai.com/avatar/8/10/79668/90x90.jpg
    public String group_bgcolor;//	71D14B
    public String group_name;//	V1会员
    public int isattention;//	0
    public int isdaren;//	1
    public List<HomePageDatas.PostInfo> pics;//	Array
    public String text;//	分享了138篇笔记，共收获了5284个赞
    public int userid;//	79668
    public String username;//	雪儿cs

}
