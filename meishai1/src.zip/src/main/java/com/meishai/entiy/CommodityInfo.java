package com.meishai.entiy;

public class CommodityInfo {
	
	public String thumb;
	public String title;
	public float price;
	public String url;
}
