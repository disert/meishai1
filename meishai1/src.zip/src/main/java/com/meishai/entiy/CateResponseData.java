package com.meishai.entiy;

import java.util.List;

public class CateResponseData extends BaseResp<CateResponseData.CateInfo1> {
	

	public class CateInfo1 {
		public int tid;
		public String title;
		public String image;
	}
}
