package com.meishai.entiy;

/**
 * Created by Administrator on 2016/3/21.
 *
 * 当跳转h5页面的时候要使用到的数据
 */
public class H5Data {
    public String action;//	sign
    public String controller;//	user
    public int islogin;//	1
    public String parameter;//
    public int userid;//	22878
}
