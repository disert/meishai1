package com.meishai.entiy;

public class UserIntro {
	
	
	private String userID;
	private String introl;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getIntrol() {
		return introl;
	}
	public void setIntrol(String introl) {
		this.introl = introl;
	}
}
