package com.meishai.entiy;

import java.util.List;

import com.meishai.entiy.StrategyResqData.StratData;

/**
 * 攻略列表数据的封装类
 * @author Administrator yl
 *
 */
public class StratListRespData extends BaseRespData{
	
	public List<StratData> list;
	public String catname;

}
