package com.meishai.ui.dialog;

public interface GetPictureCallBack {
	
	public void takePicturePath(String Path);
}
