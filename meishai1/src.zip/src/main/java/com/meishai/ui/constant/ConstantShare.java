package com.meishai.ui.constant;

/**
 * 第三方分享
 * 
 * @author sh
 *
 */
public final class ConstantShare {

	/** ------------分享到QQ和QQ空间使用 ----------------- **/
	// 1104527047 L8bRpuWjHP04xoVe
	public final static String QQ_APP_ID = "100265935";
	public final static String QQ_APP_KEY = "7e748bf7ce297af2653b9c517eb12add";

	/** ------------微信 ----------------- **/
	public final static String WX_APP_ID = "wx7111d615b4c4cd88";
	public final static String WX_APP_KEY = "7e748bf7ce297af2653b9c517eb12add";
}
