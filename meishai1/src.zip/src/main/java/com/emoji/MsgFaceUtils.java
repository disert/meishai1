package com.emoji;

public class MsgFaceUtils {
	public static String[] faceImgNames = new String[] {};

	public static int[] faceImgs = new int[] {};

}
